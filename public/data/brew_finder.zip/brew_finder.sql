-- =============================================
-- BREWERY & COFFEE SHOP FINDER DATABASE - QUEBEC
-- =============================================
-- A unique database for discovering local breweries and coffee shops in Quebec
-- Features locations in Montreal and Laval with French-Canadian flair

-- Drop database if exists and create new one
DROP DATABASE IF EXISTS brew_finder;
CREATE DATABASE brew_finder CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE brew_finder;

-- =============================================
-- CUSTOMERS TABLE
-- =============================================
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    date_of_birth DATE,
    favorite_drink_type ENUM('coffee', 'tea', 'beer', 'cocktail', 'other') DEFAULT 'coffee',
    loyalty_points INT DEFAULT 0,
    join_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- CAFES TABLE (Coffee Shops)
-- =============================================
CREATE TABLE cafes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    address VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(50) NOT NULL,
    zip_code VARCHAR(10) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(255),
    instagram_handle VARCHAR(50),
    opening_time TIME NOT NULL,
    closing_time TIME NOT NULL,
    wifi_available BOOLEAN DEFAULT TRUE,
    outdoor_seating BOOLEAN DEFAULT FALSE,
    pet_friendly BOOLEAN DEFAULT FALSE,
    parking_available BOOLEAN DEFAULT TRUE,
    roasts_own_beans BOOLEAN DEFAULT FALSE,
    specialty VARCHAR(100), -- e.g., "Single Origin", "Cold Brew", "Latte Art"
    atmosphere ENUM('cozy', 'modern', 'rustic', 'hipster', 'corporate', 'artsy') DEFAULT 'cozy',
    price_range ENUM('$', '$$', '$$$', '$$$$') DEFAULT '$$',
    average_rating DECIMAL(3,2) DEFAULT 0.00,
    total_reviews INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_city (city),
    INDEX idx_rating (average_rating),
    INDEX idx_specialty (specialty)
);

-- =============================================
-- BREWERIES TABLE
-- =============================================
CREATE TABLE breweries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    address VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(50) NOT NULL,
    zip_code VARCHAR(10) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(255),
    instagram_handle VARCHAR(50),
    opening_time TIME NOT NULL,
    closing_time TIME NOT NULL,
    brewery_type ENUM('microbrewery', 'brewpub', 'taproom', 'regional', 'contract') DEFAULT 'microbrewery',
    established_year YEAR,
    outdoor_seating BOOLEAN DEFAULT FALSE,
    food_available BOOLEAN DEFAULT FALSE,
    tours_available BOOLEAN DEFAULT FALSE,
    pet_friendly BOOLEAN DEFAULT FALSE,
    parking_available BOOLEAN DEFAULT TRUE,
    signature_beer VARCHAR(100),
    beer_styles VARCHAR(200), -- e.g., "IPA, Stout, Lager"
    atmosphere ENUM('casual', 'upscale', 'industrial', 'family-friendly', 'trendy') DEFAULT 'casual',
    price_range ENUM('$', '$$', '$$$', '$$$$') DEFAULT '$$',
    average_rating DECIMAL(3,2) DEFAULT 0.00,
    total_reviews INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_city (city),
    INDEX idx_type (brewery_type),
    INDEX idx_rating (average_rating)
);

-- =============================================
-- DRINKS TABLE
-- =============================================
CREATE TABLE drinks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category ENUM('coffee', 'tea', 'beer', 'cocktail', 'non-alcoholic', 'pastry') NOT NULL,
    subcategory VARCHAR(50), -- e.g., "IPA", "Espresso", "Green Tea", "Cocktail"
    price DECIMAL(5,2) NOT NULL,
    alcohol_content DECIMAL(4,2) DEFAULT NULL, -- For beers/cocktails
    caffeine_content VARCHAR(20) DEFAULT NULL, -- e.g., "High", "Medium", "None"
    size VARCHAR(20) DEFAULT 'Regular', -- e.g., "Small", "Regular", "Large", "Pint"
    calories INT DEFAULT NULL,
    ingredients TEXT,
    allergens VARCHAR(100), -- e.g., "Milk, Nuts, Gluten"
    vegan BOOLEAN DEFAULT FALSE,
    gluten_free BOOLEAN DEFAULT FALSE,
    seasonal BOOLEAN DEFAULT FALSE,
    available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_price (price),
    INDEX idx_available (available)
);

-- =============================================
-- CAFE_DRINKS TABLE (What drinks each cafe offers)
-- =============================================
CREATE TABLE cafe_drinks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cafe_id INT NOT NULL,
    drink_id INT NOT NULL,
    is_signature BOOLEAN DEFAULT FALSE,
    daily_special_day ENUM('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday') DEFAULT NULL,
    added_date DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (cafe_id) REFERENCES cafes(id) ON DELETE CASCADE,
    FOREIGN KEY (drink_id) REFERENCES drinks(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cafe_drink (cafe_id, drink_id)
);

-- =============================================
-- BREWERY_DRINKS TABLE (What drinks each brewery offers)
-- =============================================
CREATE TABLE brewery_drinks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    brewery_id INT NOT NULL,
    drink_id INT NOT NULL,
    is_flagship BOOLEAN DEFAULT FALSE,
    seasonal_availability VARCHAR(50) DEFAULT NULL, -- e.g., "Summer", "Winter", "Year-round"
    abv DECIMAL(4,2) DEFAULT NULL, -- Alcohol by volume
    ibu INT DEFAULT NULL, -- International Bitterness Units for beer
    added_date DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (brewery_id) REFERENCES breweries(id) ON DELETE CASCADE,
    FOREIGN KEY (drink_id) REFERENCES drinks(id) ON DELETE CASCADE,
    UNIQUE KEY unique_brewery_drink (brewery_id, drink_id)
);

-- =============================================
-- REVIEWS TABLE
-- =============================================
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    location_type ENUM('cafe', 'brewery') NOT NULL,
    location_id INT NOT NULL, -- References either cafes.id or breweries.id
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(200),
    comment TEXT,
    visited_date DATE DEFAULT (CURRENT_DATE),
    drink_ordered VARCHAR(100), -- What they ordered
    service_rating INT DEFAULT NULL CHECK (service_rating >= 1 AND service_rating <= 5),
    atmosphere_rating INT DEFAULT NULL CHECK (atmosphere_rating >= 1 AND atmosphere_rating <= 5),
    value_rating INT DEFAULT NULL CHECK (value_rating >= 1 AND value_rating <= 5),
    would_recommend BOOLEAN DEFAULT TRUE,
    photo_url VARCHAR(255) DEFAULT NULL,
    helpful_votes INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    INDEX idx_location (location_type, location_id),
    INDEX idx_rating (rating),
    INDEX idx_customer (customer_id)
);

-- =============================================
-- EVENTS TABLE (Special events at locations)
-- =============================================
CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location_type ENUM('cafe', 'brewery') NOT NULL,
    location_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    event_type ENUM('live_music', 'trivia', 'tasting', 'workshop', 'art_show', 'open_mic', 'other') NOT NULL,
    event_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME,
    price DECIMAL(6,2) DEFAULT 0.00,
    max_attendees INT DEFAULT NULL,
    requires_reservation BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_event_date (event_date),
    INDEX idx_location (location_type, location_id)
);

-- =============================================
-- INSERT SAMPLE DATA
-- =============================================

-- Insert Customers
INSERT INTO customers (first_name, last_name, email, phone, date_of_birth, favorite_drink_type, loyalty_points, join_date) VALUES
('Émilie', 'Dubois', 'emilie.dubois@email.com', '514-555-0101', '1992-03-15', 'coffee', 245, '2023-06-15'),
('Marc', 'Tremblay', 'marc.tremblay@email.com', '514-555-0102', '1988-07-22', 'beer', 380, '2023-04-20'),
('Sophie', 'Gagnon', 'sophie.gagnon@email.com', '514-555-0103', '1995-11-08', 'tea', 120, '2023-08-10'),
('Jean', 'Leblanc', 'jean.leblanc@email.com', '450-555-0104', '1990-01-30', 'coffee', 89, '2023-09-05'),
('Amélie', 'Bouchard', 'amelie.bouchard@email.com', '514-555-0105', '1993-05-17', 'cocktail', 156, '2023-07-12'),
('Alexandre', 'Roy', 'alexandre.roy@email.com', '450-555-0106', '1987-12-03', 'beer', 420, '2023-03-08'),
('Isabelle', 'Martin', 'isabelle.martin@email.com', '514-555-0107', '1996-09-25', 'coffee', 78, '2023-10-01'),
('David', 'Lavoie', 'david.lavoie@email.com', '450-555-0108', '1985-04-12', 'beer', 290, '2023-05-18');

-- Insert Cafes
INSERT INTO cafes (name, description, address, city, state, zip_code, phone, email, website, instagram_handle, opening_time, closing_time, wifi_available, outdoor_seating, pet_friendly, roasts_own_beans, specialty, atmosphere, price_range, average_rating, total_reviews) VALUES
('Café des Artisans', 'Cozy neighborhood coffee shop with house-roasted beans', '1234 Rue Saint-Denis', 'Montreal', 'QC', 'H2X 3K3', '514-555-0201', 'bonjour@cafedesartisans.ca', 'www.cafedesartisans.ca', '@cafedesartisans', '06:00:00', '20:00:00', TRUE, TRUE, TRUE, TRUE, 'Single Origin', 'cozy', '$$', 4.5, 87),
('Le Grind Quotidien', 'Modern coffee house perfect for remote work', '456 Boulevard Saint-Laurent', 'Montreal', 'QC', 'H2Y 2Y5', '514-555-0202', 'info@legrind.ca', 'www.legrindquotidien.ca', '@legrindmtl', '05:30:00', '22:00:00', TRUE, FALSE, FALSE, FALSE, 'Cold Brew', 'modern', '$$$', 4.2, 134),
('Torréfacteurs du Plateau', 'Small batch roastery with exceptional espresso', '789 Avenue du Mont-Royal', 'Montreal', 'QC', 'H2J 1X6', '514-555-0203', 'contact@torrefacteursplateau.ca', 'www.torrefacteursplateau.ca', '@torrefacteursplateau', '07:00:00', '18:00:00', TRUE, TRUE, TRUE, TRUE, 'Latte Art', 'artsy', '$$$', 4.7, 156),
('Café du Coin', 'Friendly local spot with homemade pastries', '321 Rue Sainte-Catherine', 'Montreal', 'QC', 'H3B 1A6', '514-555-0204', 'bonjour@cafecoin.ca', 'www.cafeducoincafe.ca', '@cafeducoincafe', '06:30:00', '19:00:00', TRUE, TRUE, TRUE, FALSE, 'Pastries', 'cozy', '$', 4.3, 92),
('Café Vitesse', 'High-energy spot for coffee enthusiasts', '654 Boulevard des Laurentides', 'Laval', 'QC', 'H7G 2T8', '450-555-0205', 'info@cafevitesse.ca', 'www.cafevitesse.ca', '@cafevitesselaval', '05:00:00', '21:00:00', TRUE, FALSE, FALSE, TRUE, 'Espresso', 'modern', '$$', 4.4, 203);

-- Insert Breweries
INSERT INTO breweries (name, description, address, city, state, zip_code, phone, email, website, instagram_handle, opening_time, closing_time, brewery_type, established_year, outdoor_seating, food_available, tours_available, pet_friendly, signature_beer, beer_styles, atmosphere, price_range, average_rating, total_reviews) VALUES
('Brasserie du Houblon', 'Craft brewery specializing in hoppy IPAs and rich stouts', '888 Rue Notre-Dame', 'Montreal', 'QC', 'H3C 1K3', '514-555-0301', 'info@brasseriehoublon.ca', 'www.brasseriehoublon.ca', '@brasseriehoublon', '12:00:00', '22:00:00', 'microbrewery', 2015, TRUE, TRUE, TRUE, TRUE, 'IPA Québécoise', 'IPA, Stout, Pale Ale', 'casual', '$$', 4.6, 178),
('Taverne Industrielle', 'Industrial-style taproom with rotating selection', '999 Rue Rachel', 'Montreal', 'QC', 'H2J 2J8', '514-555-0302', 'bonjour@taverneindustrielle.ca', 'www.taverneindustrielle.ca', '@taverneindust', '15:00:00', '23:00:00', 'taproom', 2018, FALSE, FALSE, FALSE, FALSE, 'Lager Vapeur', 'Lager, Wheat, Sour', 'industrial', '$$$', 4.3, 95),
('Brasseurs du Plateau', 'Montreal brewery with innovative flavors', '777 Avenue Papineau', 'Montreal', 'QC', 'H2K 4J5', '514-555-0303', 'contact@brasseursplateau.ca', 'www.brasseursplateau.ca', '@brasseursplateau', '14:00:00', '21:00:00', 'brewpub', 2012, TRUE, TRUE, TRUE, TRUE, 'Montréal Rêveur IPA', 'IPA, Pilsner, Saison', 'trendy', '$$$', 4.5, 142),
('Microbrasserie des Îles', 'Quebec-style brewery with big flavors', '555 Boulevard Saint-Martin', 'Laval', 'QC', 'H7T 1B3', '450-555-0304', 'info@microbrasserieiles.ca', 'www.microbrasseriedesiles.ca', '@microiles', '11:00:00', '24:00:00', 'regional', 2008, TRUE, TRUE, FALSE, TRUE, 'Tonnerre des Îles IPA', 'IPA, Porter, Wheat', 'family-friendly', '$$', 4.4, 267),
('Brasserie Laurentienne', 'Local brewery with natural mountain water', '432 Chemin du Souvenir', 'Laval', 'QC', 'H7W 1A3', '450-555-0305', 'bonjour@brasserielaurentienne.ca', 'www.brasserielaurentienne.ca', '@brasslaurentienne', '13:00:00', '22:00:00', 'microbrewery', 2017, TRUE, TRUE, TRUE, TRUE, 'Ale des Laurentides', 'IPA, Stout, Amber', 'casual', '$$', 4.7, 89);

-- Insert Drinks
INSERT INTO drinks (name, description, category, subcategory, price, alcohol_content, caffeine_content, size, calories, vegan, gluten_free, seasonal) VALUES
-- Coffee Drinks
('Espresso', 'Rich, concentrated coffee shot', 'coffee', 'Espresso', 2.50, NULL, 'High', 'Single', 5, TRUE, TRUE, FALSE),
('Cappuccino', 'Espresso with steamed milk and foam', 'coffee', 'Espresso', 4.25, NULL, 'Medium', 'Regular', 120, FALSE, TRUE, FALSE),
('Cold Brew', 'Smooth, cold-steeped coffee', 'coffee', 'Cold Brew', 3.75, NULL, 'High', 'Regular', 15, TRUE, TRUE, FALSE),
('Pumpkin Spice Latte', 'Seasonal autumn favorite', 'coffee', 'Latte', 5.50, NULL, 'Medium', 'Large', 280, FALSE, TRUE, TRUE),
('Nitro Cold Brew', 'Cold brew infused with nitrogen', 'coffee', 'Cold Brew', 4.50, NULL, 'High', 'Regular', 20, TRUE, TRUE, FALSE),

-- Tea Drinks
('Earl Grey', 'Classic bergamot-flavored black tea', 'tea', 'Black Tea', 3.25, NULL, 'Medium', 'Regular', 0, TRUE, TRUE, FALSE),
('Matcha Latte', 'Japanese green tea powder with steamed milk', 'tea', 'Green Tea', 4.75, NULL, 'Medium', 'Regular', 140, FALSE, TRUE, FALSE),
('Chamomile', 'Soothing herbal tea', 'tea', 'Herbal', 3.00, NULL, 'None', 'Regular', 0, TRUE, TRUE, FALSE),

-- Beer
('Hoppy IPA', 'Bold India Pale Ale with citrus notes', 'beer', 'IPA', 6.50, 6.8, NULL, 'Pint', 180, TRUE, FALSE, FALSE),
('Chocolate Stout', 'Rich stout with chocolate undertones', 'beer', 'Stout', 7.00, 5.2, NULL, 'Pint', 210, TRUE, FALSE, FALSE),
('Wheat Beer', 'Light and refreshing wheat beer', 'beer', 'Wheat', 5.50, 4.5, NULL, 'Pint', 150, TRUE, FALSE, FALSE),
('Seasonal Pumpkin Ale', 'Autumn spiced ale', 'beer', 'Seasonal', 6.75, 5.5, NULL, 'Pint', 165, TRUE, FALSE, TRUE),
('Pilsner', 'Crisp and clean lager', 'beer', 'Lager', 5.25, 4.8, NULL, 'Pint', 140, TRUE, FALSE, FALSE),

-- Cocktails
('Coffee Martini', 'Espresso-based cocktail', 'cocktail', 'Martini', 12.00, 15.0, 'High', 'Regular', 180, TRUE, TRUE, FALSE),
('Beer Cocktail', 'House beer mixed with seasonal fruit', 'cocktail', 'Beer Cocktail', 8.50, 4.2, NULL, 'Regular', 160, TRUE, FALSE, TRUE),

-- Non-Alcoholic
('Sparkling Water', 'Refreshing bubbled water', 'non-alcoholic', 'Water', 2.00, NULL, 'None', 'Regular', 0, TRUE, TRUE, FALSE),
('Fresh Orange Juice', 'Squeezed daily', 'non-alcoholic', 'Juice', 3.50, NULL, 'None', 'Regular', 110, TRUE, TRUE, FALSE),

-- Pastries
('Croissant', 'Buttery French pastry', 'pastry', 'Pastry', 3.25, NULL, 'None', 'Regular', 270, FALSE, FALSE, FALSE),
('Blueberry Muffin', 'Fresh baked with local blueberries', 'pastry', 'Muffin', 2.75, NULL, 'None', 'Regular', 320, FALSE, FALSE, FALSE);

-- Link Cafes to their Drinks
INSERT INTO cafe_drinks (cafe_id, drink_id, is_signature, daily_special_day) VALUES
-- Brew & Bean (cafe_id: 1)
(1, 1, FALSE, NULL), (1, 2, TRUE, NULL), (1, 3, FALSE, 'monday'), (1, 5, TRUE, NULL), (1, 6, FALSE, NULL), (1, 7, FALSE, NULL), (1, 16, FALSE, NULL), (1, 18, FALSE, NULL),
-- The Daily Grind (cafe_id: 2)
(2, 1, FALSE, NULL), (2, 2, FALSE, NULL), (2, 3, TRUE, NULL), (2, 5, FALSE, NULL), (2, 7, FALSE, NULL), (2, 14, TRUE, NULL), (2, 16, FALSE, NULL), (2, 19, FALSE, NULL),
-- Artisan Roasters (cafe_id: 3)
(3, 1, TRUE, NULL), (3, 2, TRUE, NULL), (3, 3, FALSE, NULL), (3, 6, FALSE, NULL), (3, 7, TRUE, NULL), (3, 18, FALSE, NULL), (3, 19, FALSE, NULL),
-- Corner Coffee (cafe_id: 4)
(4, 1, FALSE, NULL), (4, 2, FALSE, NULL), (4, 4, TRUE, 'friday'), (4, 6, FALSE, NULL), (4, 8, FALSE, NULL), (4, 17, FALSE, NULL), (4, 18, TRUE, NULL), (4, 19, TRUE, NULL),
-- Velocity Coffee (cafe_id: 5)
(5, 1, TRUE, NULL), (5, 2, FALSE, NULL), (5, 3, FALSE, NULL), (5, 5, FALSE, NULL), (5, 14, FALSE, NULL), (5, 16, FALSE, NULL), (5, 17, FALSE, NULL);

-- Link Breweries to their Drinks
INSERT INTO brewery_drinks (brewery_id, drink_id, is_flagship, seasonal_availability, abv, ibu) VALUES
-- Hop & Barley Brewing (brewery_id: 1)
(1, 9, TRUE, 'Year-round', 6.8, 65), (1, 10, FALSE, 'Year-round', 5.2, 35), (1, 11, FALSE, 'Summer', 4.5, 20), (1, 14, FALSE, 'Year-round', 15.0, NULL), (1, 16, FALSE, NULL, NULL, NULL),
-- Iron Horse Taproom (brewery_id: 2)
(2, 13, TRUE, 'Year-round', 4.8, 25), (2, 11, FALSE, 'Summer', 4.5, 20), (2, 15, FALSE, 'Fall', 4.2, NULL), (2, 16, FALSE, NULL, NULL, NULL), (2, 17, FALSE, NULL, NULL, NULL),
-- Golden State Brewing (brewery_id: 3)
(3, 9, TRUE, 'Year-round', 6.8, 65), (3, 13, FALSE, 'Year-round', 4.8, 25), (3, 11, FALSE, 'Summer', 4.5, 20), (3, 14, TRUE, 'Year-round', 15.0, NULL), (3, 16, FALSE, NULL, NULL, NULL),
-- Lone Star Brewery (brewery_id: 4)
(4, 9, TRUE, 'Year-round', 6.8, 65), (4, 10, FALSE, 'Winter', 5.2, 35), (4, 11, FALSE, 'Year-round', 4.5, 20), (4, 12, TRUE, 'Fall', 5.5, 30), (4, 16, FALSE, NULL, NULL, NULL), (4, 17, FALSE, NULL, NULL, NULL),
-- Rocky Mountain Brewing (brewery_id: 5)
(5, 9, FALSE, 'Year-round', 6.8, 65), (5, 10, TRUE, 'Year-round', 5.2, 35), (5, 13, FALSE, 'Year-round', 4.8, 25), (5, 16, FALSE, NULL, NULL, NULL);

-- Insert Reviews
INSERT INTO reviews (customer_id, location_type, location_id, rating, title, comment, visited_date, drink_ordered, service_rating, atmosphere_rating, value_rating, would_recommend) VALUES
-- Cafe Reviews
(1, 'cafe', 1, 5, 'Perfect Morning Spot', 'Love their single origin coffee! The baristas really know their craft.', '2024-01-15', 'Cappuccino', 5, 5, 4, TRUE),
(2, 'cafe', 1, 4, 'Great Coffee, Crowded', 'Excellent coffee but gets very busy in the morning.', '2024-01-20', 'Cold Brew', 4, 3, 4, TRUE),
(3, 'cafe', 2, 4, 'Good for Work', 'Reliable wifi and good coffee. Perfect for remote work.', '2024-02-01', 'Nitro Cold Brew', 4, 4, 4, TRUE),
(4, 'cafe', 3, 5, 'Amazing Latte Art', 'The barista made incredible latte art. Coffee was exceptional too!', '2024-02-10', 'Cappuccino', 5, 5, 5, TRUE),
(5, 'cafe', 4, 4, 'Homey Atmosphere', 'Love the cozy vibe and their pastries are homemade.', '2024-02-15', 'Earl Grey', 4, 5, 5, TRUE),
(1, 'cafe', 5, 4, 'Strong Coffee', 'Perfect for early morning energy boost. Very strong espresso.', '2024-02-20', 'Espresso', 4, 4, 4, TRUE),

-- Brewery Reviews
(2, 'brewery', 1, 5, 'Best IPA in Town', 'Their Northwest IPA is absolutely perfect. Great hop balance.', '2024-01-25', 'Hoppy IPA', 5, 4, 4, TRUE),
(6, 'brewery', 1, 4, 'Good Selection', 'Nice variety of beers. The stout was rich and creamy.', '2024-02-05', 'Chocolate Stout', 4, 4, 4, TRUE),
(8, 'brewery', 2, 4, 'Industrial Vibe', 'Cool atmosphere, decent beer selection.', '2024-02-12', 'Pilsner', 4, 5, 3, TRUE),
(2, 'brewery', 3, 5, 'Innovative Flavors', 'Love trying their seasonal experiments. Always something new!', '2024-02-18', 'Hoppy IPA', 5, 5, 4, TRUE),
(6, 'brewery', 4, 4, 'Family Friendly', 'Great place to bring kids. Good beer and food too.', '2024-02-22', 'Wheat Beer', 4, 5, 4, TRUE),
(8, 'brewery', 5, 5, 'Mountain Views', 'Amazing scenery with excellent craft beer. The Alpine Ale is fantastic!', '2024-02-25', 'Chocolate Stout', 5, 5, 4, TRUE),

-- Multiple reviews from same customers
(1, 'cafe', 2, 3, 'Not My Favorite', 'Coffee was okay but not exceptional for the price.', '2024-03-01', 'Cold Brew', 3, 3, 2, FALSE),
(2, 'cafe', 3, 5, 'Consistently Great', 'Always excellent service and coffee quality.', '2024-03-05', 'Espresso', 5, 4, 4, TRUE),
(6, 'brewery', 2, 3, 'Average Experience', 'Beer was fine but nothing special stood out.', '2024-03-08', 'Wheat Beer', 3, 4, 3, TRUE);

-- Insert Events
INSERT INTO events (location_type, location_id, name, description, event_type, event_date, start_time, end_time, price, max_attendees, requires_reservation) VALUES
('cafe', 1, 'Latte Art Workshop', 'Learn to create beautiful latte art with our expert baristas', 'workshop', '2024-03-15', '14:00:00', '16:00:00', 25.00, 12, TRUE),
('cafe', 3, 'Open Mic Night', 'Showcase your talent at our monthly open mic', 'open_mic', '2024-03-20', '19:00:00', '22:00:00', 0.00, NULL, FALSE),
('brewery', 1, 'IPA Tasting Flight', 'Taste 5 different IPAs with our brewmaster', 'tasting', '2024-03-18', '18:00:00', '20:00:00', 15.00, 20, TRUE),
('brewery', 3, 'Trivia Tuesday', 'Weekly trivia night with beer prizes', 'trivia', '2024-03-19', '20:00:00', '22:00:00', 0.00, NULL, FALSE),
('cafe', 2, 'Coffee Cupping', 'Professional coffee tasting and education', 'tasting', '2024-03-22', '10:00:00', '12:00:00', 20.00, 15, TRUE);

-- =============================================
-- CREATE VIEWS FOR COMMON QUERIES
-- =============================================

-- View for all drinks offered at each location
CREATE VIEW location_drinks AS
SELECT
    'cafe' as location_type,
    c.id as location_id,
    c.name as location_name,
    c.city,
    d.name as drink_name,
    d.category,
    d.price,
    cd.is_signature,
    cd.daily_special_day
FROM cafes c
JOIN cafe_drinks cd ON c.id = cd.cafe_id
JOIN drinks d ON cd.drink_id = d.id
UNION ALL
SELECT
    'brewery' as location_type,
    b.id as location_id,
    b.name as location_name,
    b.city,
    d.name as drink_name,
    d.category,
    d.price,
    bd.is_flagship as is_signature,
    NULL as daily_special_day
FROM breweries b
JOIN brewery_drinks bd ON b.id = bd.brewery_id
JOIN drinks d ON bd.drink_id = d.id;

-- View for average ratings per location
CREATE VIEW location_ratings AS
SELECT
    'cafe' as location_type,
    c.id as location_id,
    c.name as location_name,
    c.city,
    c.state,
    COALESCE(AVG(r.rating), 0) as average_rating,
    COUNT(r.id) as total_reviews
FROM cafes c
LEFT JOIN reviews r ON r.location_type = 'cafe' AND r.location_id = c.id
GROUP BY c.id
UNION ALL
SELECT
    'brewery' as location_type,
    b.id as location_id,
    b.name as location_name,
    b.city,
    b.state,
    COALESCE(AVG(r.rating), 0) as average_rating,
    COUNT(r.id) as total_reviews
FROM breweries b
LEFT JOIN reviews r ON r.location_type = 'brewery' AND r.location_id = b.id
GROUP BY b.id;

-- View for customers who reviewed multiple locations
CREATE VIEW active_reviewers AS
SELECT
    c.id,
    c.first_name,
    c.last_name,
    c.email,
    COUNT(r.id) as total_reviews,
    COUNT(DISTINCT CONCAT(r.location_type, '-', r.location_id)) as locations_reviewed,
    AVG(r.rating) as average_rating_given
FROM customers c
JOIN reviews r ON c.id = r.customer_id
GROUP BY c.id
HAVING total_reviews > 1;

-- =============================================
-- SAMPLE QUERIES FOR PRACTICE
-- =============================================

/*
-- 1. All drinks offered at a specific location
SELECT d.name, d.category, d.price, cd.is_signature
FROM cafe_drinks cd
JOIN drinks d ON cd.drink_id = d.id
WHERE cd.cafe_id = :cafe_id;

-- 2. Average review per café
SELECT c.name, AVG(r.rating) as average_rating, COUNT(r.id) as review_count
FROM cafes c
LEFT JOIN reviews r ON r.location_type = 'cafe' AND r.location_id = c.id
GROUP BY c.id, c.name;

-- 3. Customers who reviewed multiple shops
SELECT c.first_name, c.last_name, COUNT(DISTINCT CONCAT(r.location_type, '-', r.location_id)) as shops_reviewed
FROM customers c
JOIN reviews r ON c.id = r.customer_id
GROUP BY c.id
HAVING shops_reviewed > 1;

-- 4. Find all coffee shops with outdoor seating in Montreal
SELECT name, address, specialty, average_rating
FROM cafes
WHERE city = 'Montreal' AND outdoor_seating = TRUE;

-- 5. Best rated breweries that serve IPAs
SELECT b.name, b.city, AVG(r.rating) as avg_rating
FROM breweries b
JOIN brewery_drinks bd ON b.id = bd.brewery_id
JOIN drinks d ON bd.drink_id = d.id
LEFT JOIN reviews r ON r.location_type = 'brewery' AND r.location_id = b.id
WHERE d.subcategory = 'IPA'
GROUP BY b.id
ORDER BY avg_rating DESC;

-- 6. Coffee shops with WiFi perfect for remote work
SELECT name, city, wifi_available, atmosphere, price_range, average_rating
FROM cafes
WHERE wifi_available = TRUE AND atmosphere IN ('modern', 'cozy')
ORDER BY average_rating DESC;

-- 7. Seasonal drinks currently available
SELECT d.name, d.category, d.price, d.description
FROM drinks d
WHERE d.seasonal = TRUE AND d.available = TRUE;

-- 8. Most active reviewers
SELECT c.first_name, c.last_name, COUNT(r.id) as review_count, AVG(r.rating) as avg_rating_given
FROM customers c
JOIN reviews r ON c.id = r.customer_id
GROUP BY c.id
ORDER BY review_count DESC
LIMIT 5;
*/

-- =============================================
-- END OF DATABASE SETUP
-- =============================================

-- Display success message
SELECT 'Brewery & Coffee Shop Finder database created successfully! Featuring Montreal and Laval locations. Perfect for PDO practice with interesting queries.' AS message;
